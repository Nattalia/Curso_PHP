Sapling Template by Warm Forest Flash

GETTING STARTED
Open up "index.html" in either of the two demo folders (whichever one you like more) with your web browser. Open up "settings.xml" with a text editor and start changing the settings. Refresh "index.html" to see the changes.

SUPPORT
For support, please read the help file here:
http://www.warmforestflash.com/products/sapling/help/

TERMS OF USE
Warm Forest templates may be used in any kind of personal and/or commercial project. Each purchase provides a single user, single website license. Warm Forest templates and source code may not be redistributed or resold to other companies or third parties.

All templates are Copyright 2010 Warm Forest. All rights reserved.